

<html>
<head>
    <title>Netflix Website</title>
    <style>
        body
        {

            background-color: pink;
        }
    </style>
</head>
<body style="text-align: center">
<h1>Welcome To The Netflix Website</h1>
<p>Here you can explore information about movies </p>
<img src="netflix.jpg" alt="Netflix" style="height: 200px; width: 200px;"/></body>
<br>
<br>
<a href="NewMovie.php" target="_self" style="font-size:24px">Add a new Movie here</a><br><br>
<a href="NewFile.php" target="_self" style="font-size:24px">Add Movie from a File</a><br><br>
<?php
// Connecting to the database
$server = "tcp:techniondbcourse01.database.windows.net,1433";
$user = "olga0perich";
$pass = "Qwerty12!";
$database = "olga0perich";
$c = array("Database" => $database, "UID" => $user, "PWD" => $pass);
sqlsrv_configure('WarningsReturnAsErrors', 0);
$conn = sqlsrv_connect($server, $c);
if($conn === false)
{
    echo "error";
    die(print_r(sqlsrv_errors(), true));
}
//echo "connected to DB"; //debug
?>
<h2>Longest movies for each year which satisfy the given conditions:</h2>
<table border="1" cellpadding="5" style="margin-left:auto; margin-right:auto;">
    <tr>
        <th>Year</th><th>Title</th><th>Duration</th>
    </tr>
    <?php

            $sql ="select distinct a.release_year,n.title,a.Duration
        from(select a.release_year,max(a.duration) as Duration
        from Netflix a
        where a.country not like 'United States'
          and a.director not like '%,%'
        group by release_year
        )a, Netflix n
        where n.duration = a.Duration
        and n.release_year = a.release_year
        order by release_year desc";

    $result = sqlsrv_query($conn, $sql);
    while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC))
    {
        echo '<tr>';
        echo '<td>'.$row['release_year'].'</td>';
        echo '<td>'.$row['title'].'</td>';
        echo '<td>'.$row['Duration'].'</td>';
        echo '</tr>';
    }
    ?>
</table>
<br>
<br>
</body>
</html>