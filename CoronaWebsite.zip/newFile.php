<html>
<head>
    <title> New File Form</title>
    <style>
        body
        {
            background-color: pink;
        }
    </style>
</head>
<body style="text-align: center">
<h1>Add File</h1><br>
<h2>Choose File:</h2><br><br>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
    <input type="file" name="new_file"><br><br>
    <button name="submit" type="submit" value="Send">submit</button>
</form>
<a href="index.php" target="_self" style="font-size:24px">Back home</a><br><br>


<?php
if (isset($_POST["submit"]))
{
    $server = "tcp:techniondbcourse01.database.windows.net,1433";
    $user = "olga0perich";
    $pass = "Qwerty12!";
    $database = "olga0perich";
    $c = array("Database" => $database, "UID" => $user, "PWD" => $pass);
    sqlsrv_configure('WarningsReturnAsErrors', 0);
    $conn = sqlsrv_connect($server, $c);
    if($conn === false)
    {
        echo "error";
        die(print_r(sqlsrv_errors(), true));
    }
    $file = $_FILES[new_file][tmp_name];
    if (($handle = fopen($file, "r")) !== FALSE)
    {
        $count_bad=0;
        $count_good=0;

        while (($data = fgetcsv($handle, 0, ",")) !== FALSE)
        {
            $sql="INSERT INTO Netflix(title,director,cast,country,release_year,duration,listed_in) VALUES('".addslashes($data[0])."','".addslashes($data[1])."','" .addslashes($data[2])."','".addslashes($data[3])."','".addslashes($data[4])."','".addslashes($data[5])."','".addslashes($data[6])."');";
            $result = sqlsrv_query($conn, $sql);
            if($result)
            {$count_good=$count_good+1;}
            else
                {$count_bad=$count_bad+1;}
        }
        // In case of failure

            echo "The number of records that added successfully is:" ,$count_good;
            echo".<br>";
            echo"There numbers of records that had  a problem adding the is:",$count_bad ;
        fclose($handle);
    }
}


?>
</body>
</html>



