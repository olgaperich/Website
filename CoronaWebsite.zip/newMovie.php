<html>
<head>
    <title> New Movie Form</title>
    <style>
        body
        {
            background-color: pink;
        }
    </style>
</head>
<body style="text-align: center">
<h1>New Movie</h1><br>
<h2>Fill movie Details:</h2>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
    <table border="0" cellpadding="5" style="margin-left:auto; margin-right:auto;">
        <tr>
            <td>Title:</td>
            <td><textarea name="title" Rows="5" cols="60" required></textarea></td>
        </tr>
        <tr>
            <td>Director:</td>
            <td><textarea name="director" Rows="5" cols="60" required></textarea></td>
        </tr>
        <tr>
            <td>Cast:</td>
            <td><textarea name="cast" Rows="5" cols="60" required></textarea></td>
        </tr>
        <tr>
            <td>Country:</td>
            <td><textarea  type="text" name="country" Rows="5" cols="60" required></textarea></td>
        </tr>
        <tr>
            <td>Release Year:</td>
            <td><input type="number" name="release_year"  min="1900" max="2020" step="1" style="text-align: right"></td>
        </tr>
        <tr>
            <td>Duration:</td>
            <td><input type="range" name="duration"  min="20" max="200" step="1" required> </td>
        </tr>
        <tr>
            <td>Listed in :</td>
            <td><textarea  type="text" name="listed_in" Rows="5" cols="60" ></textarea></td>
        </tr>

    </table>
    <br>
    <button name="submit" type="submit" value="Send">Send</button><br><br>
    <button type="reset" value="reset">reset</button>
</form>
<a href="index.php" target="_self" style="font-size:24px">Back home</a><br><br>

<?php
//echo "connected to DB"; //debug
// In case of success
$server = "tcp:techniondbcourse01.database.windows.net,1433";
$user = "olga0perich";
$pass = "Qwerty12!";
$database = "olga0perich";
$c = array("Database" => $database, "UID" => $user, "PWD" => $pass);
sqlsrv_configure('WarningsReturnAsErrors', 0);
$conn = sqlsrv_connect($server, $c);
if($conn === false)
{
    echo "error";
    die(print_r(sqlsrv_errors(), true));
}
if (isset($_POST["submit"]))
{
    $sql = "INSERT INTO Netflix(title,director,cast,country,release_year,duration,listed_in) VALUES('" .$_POST['title']. "','" .$_POST['director']. "','" .$_POST['cast']. "','" .$_POST['country']. "','" .$_POST['release_year']. "','" .$_POST['duration']. "','" .$_POST['listed_in']. "');";
    // echo $sql."<br>"; //debug
    $result = sqlsrv_query($conn, $sql);
    // In case of failure
    if (!$result)
    {
        die("There was a problem adding the movie to the database.<br><br>");
    }
    echo "Your movie was added to the database successfully!<br><br>";
}
?>
</body>
</html>

